# 5. Innovation, differentiation and roadmap

## Differentiators vs "EV-relabelled" ICE tyres
- **Bidirectional-torque design:** pattern and stiffness map built for drive plus regen on the same tyre
- **Zone-split compound:** addresses the RR/grip/wear triangle structurally
- **EV-rated load and thermal construct:** validated by EV-specific test cycles, giving OEMs measurable claims

## Roadmap (not in base cost)
- Pressure-sensing-ready design for OEM telematics
- Bio-based/recycled content (rice-husk silica, sustainable carbon black)
- Puncture-protection variant for delivery fleets
- Deliberately deferred: graphene tread, airless tyres, embedded sensors
