# 7. Round 2 deck plan (15 slides)

| # | Slide | # | Slide |
|---|---|---|---|
| 1 | Problem and EV-specific demands | 9 | Thermal management |
| 2 | Thesis and concept overview | 10 | Compliance and test plan |
| 3 | Construct | 11 | Cost model |
| 4 | Compound composition | 12 | Manufacturing fit and process changes |
| 5 | Tread pattern | 13 | Differentiation vs ICE-era tyres |
| 6 | NVH strategy | 14 | Risks, validation and timeline |
| 7 | Load rating and handling | 15 | Summary and next steps |
| 8 | Grip, speed, damage, durability | | |
