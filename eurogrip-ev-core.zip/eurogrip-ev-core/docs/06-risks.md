# 6. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Silica compound lowers wet grip or hurts processing | Tune polymer functionalisation, resin level, mixing; stage-gate lab to plant trial |
| Higher inflation pressure reduces comfort/grip | Balance with apex/crown design; OEM ride testing |
| Cost exceeds target | Core/Pro tiers, local silica/polymer sourcing, premium materials only where needed |
| Regen wear not as predicted | Early rig and fleet tests with motor-controller regen settings; adjust block base and chamfers |
| Standards differ across markets | Design to strictest case; maintain market-by-market compliance matrix |
