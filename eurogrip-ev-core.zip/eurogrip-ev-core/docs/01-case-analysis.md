# 1. Case analysis

## What the problem is really asking
Five engineering demands plus two hard constraints (global compliance; mass-market cost on existing plants). The winning answer is the best engineered trade-off, not the most exotic material. Graphene tread, airless tyres and embedded sensors are roadmap items, not the core product.

## How EV two-wheelers differ from ICE
| Factor | ICE | EV | Tyre consequence |
|---|---|---|---|
| Torque | Gradual, gear/clutch modulated | Peak torque from zero rpm | Higher launch shear, faster rear wear; need shoulder/centre stiffness and abrasion-resistant compound |
| Braking | Friction; engine braking minor | Regen on driven (rear) wheel, repeated | Bidirectional longitudinal force; directional patterns not ideal; heel-toe wear and heat cycling risk |
| Weight | Lighter | Battery adds ~15-40 kg; hub motor adds unsprung mass | Higher load index; more pinch-shock stress |
| Noise | Engine masks tyre noise | Near silent | Pattern noise and harshness noticed; pitch sequencing becomes a selling point |
| Energy | Fuel cost dominates; RR minor | Range is key; RR is a direct lever | Low-hysteresis compounds, optimised crown/shape |
| Duty | Mixed | Urban stop-start, fleet/delivery | Durability, cut resistance, heat management |

## The central trade-off (magic triangle)
Rolling resistance, wet grip and wear. Lower hysteresis (tan delta at ~60 C) cuts RR but tends to reduce wet grip (tan delta at ~0 C); very hard compounds protect wear but hurt grip. EV torque tightens the triangle.

**Strategy:** assign function by zone and layer. Grip at shoulder/contact edges, low loss at centre crown/under-tread/sidewall, stiffness at the block base where torque loads concentrate.

## Targets (validate in Round 2)
- RR: 15-20% lower than current ICE-era equivalent, roughly +2-4% real-world urban range
- Wear life: at least equal to ICE-era tyre; wet grip equal or better
- Load: +2 to +3 load-index steps at same size and speed symbol
- Noise: -2 to -3 dB(A) vs baseline pattern (internal target, jury tested)
