# 2. Engineering concept

## Construct
- **Architecture:** keep proven construction per segment. Tubeless bias/bias-belted for 10-12 inch scooters; radial option for 17-inch motorcycle-style EVs.
- **Carcass:** high-tenacity nylon 6,6 / polyester hybrid plies, tuned EPI and twist. Optional aramid-blend cap/belt only on the premium high-speed (R-S-H) variant.
- **Crown and gauge:** flatter, wider-radius crown; reduced shoulder gauge to cut hysteretic heat.
- **Apex/bead:** higher-modulus apex and bead filler for lateral stiffness without harming comfort.
- **Inner liner:** halobutyl tubeless liner (pressure drift raises RR and heat). Self-sealing layer optional for fleet/premium.

## Compound composition (indicative; lab starting points)
| Component | Composition | Rationale |
|---|---|---|
| Tread cap, centre | Functionalised S-SBR + BR; precipitated or rice-husk silica ~50-65 phr; blocked/low-VOC silane; reduced carbon black; low-PAH oil; optional resin | Lower hysteresis at 60 C, retained wet grip at 0 C |
| Tread cap, shoulder | Higher-Tg/higher-grip blend, more carbon black | Lean-angle grip, launch abrasion resistance |
| Base/under-tread | Low-hysteresis NR-rich, moderate CB, thermally conductive | Less heat, conducts heat away from belt |
| Sidewall | NR/BR with antiozonant/wax, cut-resistant | Damage, ozone/UV, flex fatigue |
| Liner/bead/apex | Halobutyl liner; high-modulus apex | Air retention, stiffness |

## Tread pattern
- Torque-balanced, non-directional layout with symmetric leading/trailing edge stiffness (avoids saw-tooth wear).
- Thicker block base, chamfered edges against heel-toe wear.
- Void ratio ~10-14% rear, slightly higher front; angled water-evacuation grooves; tuned via CAE and wet tests.
- NVH: 4-5 pitch lengths, frequency-spectrum spreading, aligned groove angles, smooth block entry.
- Front prioritises steering and water clearance; rear prioritises traction/regen stability, load, even wear.

## Grip, speed, damage, durability
| Need | Approach |
|---|---|
| Grip | Silica centre + high-grip shoulder; groove geometry for aquaplaning; wet braking and lean-angle track validation |
| High-speed stability | Speed symbol per vehicle (P/R/S urban, higher for fast bikes); cap ply/belt; uniformity control |
| Damage resistance | Cut-resistant shoulder, thicker chafer, pinch-shock carcass, tubeless sealing |
| Durability | Antioxidant/antiozonant package, tuned adhesion, fatigue-resistant sidewall, heat-ageing tests |

## Load rating
Example: 120 kg kerb + 150 kg rider/pillion = 270 kg gross. At 55-60% rear share the rear tyre carries ~150-160 kg before margin. Moving from LI 51 (195 kg) to LI 54 (212 kg) restores margin via carcass, apex and higher design pressure. Final sizing must follow OEM axle loads and the applicable load-pressure tables. See `src/ev_core/load_rating.py`.

## Thermal management
1. Reduce heat at source (low-hysteresis compounds, lower shoulder/sidewall gauge)
2. Conduct and shed heat (conductive under-tread, rim/shoulder ribs and vent features)
3. Resist heat damage (heat-ageing adhesion, avoid thick rubber at belt edge)
4. Validate with drum tests using cyclic drive/regen torque, repeated decel cycles, IR/thermocouple crown and shoulder temps
