# 8. Round 1 two-minute video outline

| Time | Content |
|---|---|
| 0:00-0:20 | Problem: EV two-wheelers stress tyres differently (torque, regen, weight, silence) and tyres decide range |
| 0:20-1:10 | Concept: three pillars (dual-zone low-hysteresis compound; bidirectional-torque tread with NVH pitch design; load-scaled thermally managed construct) |
| 1:10-1:35 | Global compliance (ECE R75, DOT, BIS/AIS, REACH) and EV-specific internal tests |
| 1:35-1:55 | Cost (+8 to +12%), same plant processes, range value for OEMs |
| 1:55-2:00 | Close: prototype and test plan for Round 2 |
