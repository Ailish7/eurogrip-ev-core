# 3. Compliance and testing plan

| Area | Standard / requirement | Approach |
|---|---|---|
| Type approval | UN ECE R75; US DOT FMVSS 119; India BIS/AIS | Design to strictest load/speed endurance set; confirm latest standards per market |
| Chemical | EU REACH (PAH limits for extender oils) | Low-PAH oils; restricted-substance list in formulation system |
| Rolling resistance | Drum methodology (ISO-aligned, adapted for 2W sizes) | Repeatable drum benchmark vs ICE equivalent; OEM range cycle verification |
| EV-specific (internal) | Torque-cycle wear, regen-cycle heat soak, high-load endurance, pothole/pinch-shock | Defines Eurogrip's "EV-rated" claim |
| Noise / NVH | Vehicle-level regulations + drum/pass-by + subjective jury | Pitch sequencing validated on drum and vehicle |

Note: the EU tyre label regulation does not currently cover motorcycle tyres, so type approval and chemical compliance are the primary gates. Recheck standards with the compliance team before submission.
