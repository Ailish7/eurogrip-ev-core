# 4. Cost and manufacturability

| Item | Change vs ICE-equivalent | Indicative cost |
|---|---|---|
| Silica/silane compound | Higher-cost filler and coupling agent | +3 to +5% |
| Functionalised S-SBR | Higher-cost tread polymer | +1 to +2% |
| Carcass reinforcement | Higher-tenacity cord / denser plies | +2 to +3% |
| Duplex tread | Co-extrusion, same volume | ~0 to +1% |
| Pattern / moulds | One-time tooling | ~0 to +1% |
| **Total (as stated in case)** | | **+8 to +12%** |

> **Reconciliation flag:** the line items sum to +6% (all lows) to +12% (all highs). The stated +8% floor implies the low end is not simply additive, so Round 2 should either justify the floor or restate it as +6 to +12%. `ev_core.cost_model` reports both.

## Plant fit
Same mixing, extrusion, building, curing and inspection lines. Needs silica-capable multi-stage mixing (temperature control, ethanol venting), a duplex tread extruder (common in 2W) and new moulds. Plants already running silica need no change.

## Supply chain
Rice-husk silica and domestic S-SBR/BR can cut cost and improve local sourcing; dual-source silane.

## Commercial logic
- OEMs buy range: 3% range gain ~ 0.1 kWh battery ~ INR 800-1,000 per vehicle (illustrative), above the tyre-pair premium.
- Fleets value wear life and uptime.
- Phased launch: OEM fitment on one or two scooter sizes, then aftermarket.
- One platform, two tiers: Core and Pro (aramid-blend cap/belt).
