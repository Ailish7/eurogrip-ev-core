import sys, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ev_core import load_rating as lr, cost_model as cm, range_model as rm


class TestLoad(unittest.TestCase):
    def test_case_example(self):
        g = lr.gross_mass(120, 150)
        self.assertEqual(g, 270)
        self.assertAlmostEqual(lr.rear_tyre_load(g, 0.55), 148.5)
        self.assertAlmostEqual(lr.rear_tyre_load(g, 0.60), 162.0)

    def test_li_table_matches_case(self):
        self.assertEqual(lr.LOAD_INDEX_KG[51], 195)
        self.assertEqual(lr.LOAD_INDEX_KG[54], 212)

    def test_min_li(self):
        self.assertEqual(lr.min_load_index(162), 45)
        self.assertEqual(lr.min_load_index(162, margin=0.2), 51)

    def test_bad_share(self):
        with self.assertRaises(ValueError):
            lr.rear_tyre_load(270, 1.2)


class TestCost(unittest.TestCase):
    def test_total(self):
        items = cm.load_items()
        self.assertEqual(cm.total_range(items), (6.0, 12.0))

    def test_flags_floor_mismatch(self):
        self.assertFalse(cm.reconciles_with_case(cm.load_items()))


class TestRange(unittest.TestCase):
    def test_case_value(self):
        self.assertAlmostEqual(rm.battery_kwh_saved(3, 3.33), 0.1, places=2)
        self.assertTrue(800 <= rm.oem_value_inr(3, 3.33, 9000) <= 1000)

    def test_rr_to_range_in_claimed_band(self):
        for cut in (15, 20):
            self.assertTrue(2 <= rm.range_gain_from_rr(cut) <= 4)


if __name__ == "__main__":
    unittest.main()
